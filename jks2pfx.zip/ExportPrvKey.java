/*
 * Java Keystore JKS Export Private Key to PKCS8 format 
 * Copyright � 2005 TJ (tj@tjworld.net)
 * 
 * The GNU General Public License version 2 or later applies.
 * http://www.gnu.org/licenses/gpl.html
 * 
 * Exports a private key from a (standard) Java JKS keystore file  
 */
import java.io.FileInputStream;
import java.security.KeyStore;
import java.security.Key;
 
/**
 * Exports a private key from a (standard) Java JKS keystore file  
 * 
 * @author tj
 */
public class ExportPrvKey {
	/**
	 * Exports a private key from a (standard) Java JKS keystore file.</b>
	 * Modified from code published at http://forum.java.sun.com/thread.jspa?threadID=154587&tstart=195
	 * by alef-sun.</b>
	 * Invoke with:</b>
	 * 
	 * java ExportPrvKey keystore password alias</b>
	 * 
	 * @param args Command Line Arguments
	 */
	static public void main(String[] args) {
		if(args.length < 3)
			System.out.println("usage: java ExportPrvKey keystore password alias");
		try {
			KeyStore ks = KeyStore.getInstance("jks");
			ks.load(new FileInputStream(args[0]), args[1].toCharArray());
			Key key = ks.getKey(args[2], args[1].toCharArray());
			System.out.write(key.getEncoded());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
